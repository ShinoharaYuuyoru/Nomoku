//
//  Evaluator.h
//  AplahaBetaTest
//
//

#ifndef Evaluator_h
#define Evaluator_h
#include <vector>

class Evaluator
{
public:
    std::vector<std::vector<int>> value_table;
    std::vector<std::vector<int>> board_state;
    
    int evaluate();
    void clear_board_state();
    
    Evaluator();
    ~Evaluator();
};

#endif /* Evaluator_h */
