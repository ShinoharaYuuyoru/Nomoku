//
//  Evaluator.cpp
//  AplahaBetaTest
//
//
//  Left as interface, to evaluate the current game state

#include "Evaluator.h"
#include <cstdlib>

int Evaluator::evaluate()
{
    //TODO: implement ANN evaluation algorithm here
    return std::rand()%1000;
}

Evaluator::Evaluator(){}

Evaluator::~Evaluator(){}
