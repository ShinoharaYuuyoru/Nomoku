//
//  Logger.cpp
//  AplahaBetaTest
//
//

#include "Logger.h"
#include <ctime>
#include <chrono>
#include <iostream>

std::string Levels[4] ={"DBUG","INFO","WARN","ERRO"};

void logEvent(int level,std::string log_info,...){
    
    std::time_t now = std::time(nullptr);
    struct tm *nt = std::localtime(&now);
    std::cout<<'['<<Levels[level]<<']' \
    <<nt->tm_year+1900<<'-'<<nt->tm_mon+1<<'-'<<nt->tm_mday<<' '
    <<nt->tm_hour<<':'<<nt->tm_min<<':'<<nt->tm_sec<<' ';
    
    va_list args;
    va_start(args, log_info);
    vprintf(log_info.c_str(),args);
    va_end(args);
}
