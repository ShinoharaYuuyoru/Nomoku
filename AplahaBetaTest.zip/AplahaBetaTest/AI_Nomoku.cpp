//
//  AI_Nomoku.cpp
//  AplahaBetaTest
//
//  Main AI structure
//  Where alpha-beta & minmax search was implemented
//

#include "AI_Nomoku.h"
#include "Logger.h"
#include "Board_controller.h"
#include <vector>

AI_Nomoku::AI_Nomoku(int width,int height):board_controller(width,height){}

AI_Nomoku::~AI_Nomoku(){}

void AI_Nomoku::visualize()
{
    //warp private function
    board_controller.visualize();
}

void AI_Nomoku::alpha_beta_search()
{
    if(board_controller.is_empty())
    {
        //1.whole empty board -> place on center
        if(board_controller.getWidth() >= 5 && board_controller.getHeight() >= 5)
        {
            //make sure there are at least four blocks
            board_controller.move_self(board_controller.getHeight()/2, board_controller.getWidth()/2);
        }
        else{
            logEvent(LOG_ERROR, "The board size is too small for Gomoku!");
        }
    }
    else
    {
        //2.has some dots -> expand from current dots
        int min = INT_MAX,max = INT_MIN;
        int max_x = 0,max_y = 0;
        int current_value;
        std::vector<std::pair<int, int>> v_expand_a;
        
        //alpha search
        //find alpha expandable blocks (my possible moves)
        board_controller.mark_edge_blocks();
        //collect marked blocks
        for (int i = 0; i < board_controller.getHeight(); ++i)
        {
            for (int j = 0 ; j < board_controller.getWidth(); ++j)
            {
                //in order to prevent redundant,we use TO_EXPAND mark
                if (board_controller.board[i][j] == TO_EXPAND) {
                    std::pair<int,int> temp;
                    temp.first = i;
                    temp.second = j;
                    v_expand_a.push_back(temp);
                }
            }
        }
        board_controller.visualize();
        
        for(std::pair<int, int> current_expand_a : v_expand_a)
        {
            board_controller.mark_edge_blocks();
            //expand each one of them
            std::vector<std::pair<int, int>> v_expand_b;
            int x = current_expand_a.first,y = current_expand_a.second;
            board_controller.expand(x, y);
            board_controller.visualize();
            //temporary change, will roll back
            board_controller.board[x][y] = MY_MOVE;
            
            //beta search
            //get beta expandable blocks(oppo possible moves)
            for (int i = 0; i < board_controller.getHeight(); ++i)
            {
                for (int j = 0 ; j < board_controller.getWidth(); ++j)
                {
                    if (board_controller.board[i][j] == TO_EXPAND) {
                        std::pair<int,int> temp;
                        temp.first = i;
                        temp.second = j;
                        v_expand_b.push_back(temp);
                    }
                }
            }
            
            board_controller.visualize();
            board_controller.clear_expand_marks();
            board_controller.visualize();
            
            //evaluate part
            for(std::pair<int, int> current_expand_b : v_expand_b)
            {
                min = INT_MAX;
                int x = current_expand_b.first,y = current_expand_b.second;
                //temporary change, will roll back
                board_controller.board[x][y] = OP_MOVE;
                board_controller.visualize();
                //get the current board state
                evaluator.board_state = board_controller.board;
                
                //evaluate
                current_value = evaluator.evaluate();
                if (current_value < min) {
                    min = current_value;
                }
                
                //roll back
                board_controller.board[x][y] = FREE;
                
                //minmax pruning
                if(min < max)
                    break;
            }
            if (min > max) {
                max = min;
                max_x = x,max_y = y;
            }
            
            //roll back
            board_controller.board[x][y] = TO_EXPAND;
        }
        
        board_controller.board[max_x][max_y] = MY_MOVE;
    }
    
    board_controller.clear_expand_marks();
    
}
