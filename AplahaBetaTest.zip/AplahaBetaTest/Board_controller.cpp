//
//  Board_controller.cpp
//  AplahaBetaTest
//
//  This class stores board infomation
//  and apply operations to the board
//

#include <iostream>
#include <vector>
#include "Logger.h"
#include "Board_controller.h"

Board_controller::Board_controller(int w,int h):width(w),height(h),i_e(true)
{
    //set entire board into FREE->0
    for (int i = 0; i < height; ++i) {
        std::vector<int> temp;
        for (int j = 0; j < width; ++j) {
            temp.push_back(FREE);
        }
        board.push_back(temp);
    }
}

Board_controller::~Board_controller(){}

void Board_controller::visualize()
{
    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            std::cout<<board[i][j];
        }
        std::cout<<'\n';
    }
    std::cout<<'\n';
}

bool Board_controller::is_empty()
{
    return i_e;
}

bool Board_controller::is_free(int x, int y)
{
    if (x < 0 || x >= height)
        logEvent(LOG_ERROR, "Invalid position %d,%d\n",x,y);
    if (y < 0 || y >= width)
        logEvent(LOG_ERROR, "Invalid position %d,%d\n",x,y);
    
    return (board[x][y] == FREE);
}

void Board_controller::move_self(int x, int y)
{
    if(is_free(x, y))
    {
        i_e = false;
        board[x][y] = MY_MOVE;
    }
    else{
        logEvent(LOG_ERROR, "Invalid move! The board %d,%d is not empty\n",x,y);
    }
}

void Board_controller::move_oppo(int x, int y)
{
    if(is_free(x, y))
    {
        i_e = false;
        board[x][y] = OP_MOVE;
    }
    else{
        logEvent(LOG_ERROR, "Invalid move! The board %d,%d is not empty\n",x,y);
    }
}

int Board_controller::getWidth()
{
    return width;
}

int Board_controller::getHeight()
{
    return height;
}

void Board_controller::mark_edge_blocks()
{
    for (int i = 0; i < height; ++i)
    {
        for (int j = 0 ; j < width ; ++j)
        {
            if (board[i][j] == MY_MOVE || board[i][j] == OP_MOVE)
            {
                expand(i, j);
            }
        }
    }
}

void Board_controller::expand(int x,int y)
{
    int up_tag,down_tag,left_tag,right_tag;
    //if tag is ture then it's a valid move, otherwise it's invalid
    up_tag = (x-1 >= 0);
    left_tag = (y-1 >= 0);
    down_tag = (x <= height-1);
    right_tag = (y <= width-1);
    
    //expand the blocks at the edge of existing moves
    if(up_tag && is_free(x-1, y))
        board[x-1][y] = TO_EXPAND;
    if(down_tag && is_free(x+1, y))
        board[x+1][y] = TO_EXPAND;
    if (left_tag && is_free(x, y-1))
        board[x][y-1] = TO_EXPAND;
    if (right_tag && is_free(x, y+1))
        board[x][y+1] = TO_EXPAND;
    if (up_tag && left_tag && is_free(x-1, y-1))
        board[x-1][y-1] = TO_EXPAND;
    if (up_tag && right_tag && is_free(x-1, y+1))
        board[x-1][y+1] = TO_EXPAND;
    if (down_tag && left_tag && is_free(x+1, y-1))
        board[x+1][y-1] = TO_EXPAND;
    if (down_tag && right_tag && is_free(x+1, y+1))
        board[x+1][y+1] = TO_EXPAND;
}

void Board_controller::clear_expand_marks()
{
    for (int i = 0; i < height; ++i)
    {
        for (int j = 0 ; j < width ; ++j)
        {
            if (board[i][j] == TO_EXPAND) {
                board[i][j] = FREE;
            }
        }
    }
}
