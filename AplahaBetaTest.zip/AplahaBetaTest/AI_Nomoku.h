//
//  AI_Nomoku.h
//  AplahaBetaTest
//
//

#ifndef AI_Nomoku_h
#define AI_Nomoku_h

#include "Board_controller.h"
#include "Evaluator.h"

class AI_Nomoku
{
    Board_controller board_controller;
    Evaluator  evaluator;
    
public:
    
    void alpha_beta_search();
    void visualize();
    
    AI_Nomoku(int width,int height);
    ~AI_Nomoku();
};

#endif /* AI_Nomoku_h */
