//
//  Board_controller.h
//  AplahaBetaTest
//
//  Created by 林理露 on 08/02/2017.
//  Copyright © 2017 林理露. All rights reserved.
//

#ifndef Board_controller_h
#define Board_controller_h
#include <vector>

enum{FREE,MY_MOVE,OP_MOVE,PRESERVED,TO_EXPAND};

class Board_controller
{
    int width;
    int height;
    bool i_e;
    
public:
    
    std::vector<std::vector<int>> board;
    
    Board_controller(int w,int h);
    ~Board_controller();
    
    //getter setter
    int getWidth();
    int getHeight();
    
    bool is_empty();
    bool is_free(int x,int y);
    
    void move_self(int x,int y);
    void move_oppo(int x,int y);
    
    void visualize();
    void mark_edge_blocks();
    void clear_expand_marks();
    
    void expand(int x,int y);
    
};



#endif /* Board_controller_h */
