//
//  main.cpp
//  AplahaBetaTest
//
//  Created by 林理露 on 08/02/2017.
//  Copyright © 2017 林理露. All rights reserved.
//

#include <iostream>
#include "AI_Nomoku.h"
#include "Logger.h"

int main(int argc, const char * argv[]) {
    //this is where alpha-beta search take place
    AI_Nomoku ai(10,10);
    
    //alpha-beta search for several times
    for (int i = 0; i < 3; ++i) {
        ai.alpha_beta_search();
    }
    ai.visualize();
    return 0;
}
